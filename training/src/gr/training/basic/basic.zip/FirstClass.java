package gr.training.basic;

public class FirstClass {

	//Αυτη εδώ είναι μια συνάρτηση το όνομα της είναι Main. 
	//Από την main ξεκινάει ένα java πρόγραμμα.
	//το void συμαίνει ότι δεν επιστρέφει τίποτα. 
	//το String[] σημαίνει ότι ο τύπος των παραμέτρων που δέχεται είναι πίνακας από αλφαριθμητικά
	//το args είναι το όνομα της παραμέτρου.
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//H πρώτη μας εντολή που εκτυπώνει στην consola ένα αλφαριθμητικό.
		System.out.println("Welcome akis to java programming");
	}

}
