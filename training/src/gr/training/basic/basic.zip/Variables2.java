package gr.training.basic;
//Θα μάθουμε τους τύπους της Java
public class Variables2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Αυτό είναι μια μεταβλητή αριθμος ακαίρεος
		
		int  arithmos;
		//Αυτή είναι μια μεταβλητή boolean που παίρνει τιμές true false ,
		boolean var;
		//Αυτό είναι μια μεταβλητή τύπου float δηλαδή δεκαδικού
		float var1;
		String var3;
		
		
		arithmos =2;
		var = true;
		var1 = 1.3f;
		
		var3="text";
		
		System.out.println(arithmos);
		System.out.println(var);
		System.out.println(var1);
		System.out.println(var3);
		
		
		
	}

}
