package gr.training.basic;

public class Praksis1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Ορισμός
		int i;
		//Ανάθεση τιμής 0
		i=0;
		System.out.println(i);
		//αναθεση τιμή με την prohgoumenh τιμη συν 1
		i=i+1;
		//ΕΚτύπωση
		System.out.println(i);
		
	}

}
