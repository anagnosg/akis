package gr.training.basic;

public class Pakseis4 {
	public static void main(String[] args) {
		String s ;
		s="akis";
		System.out.println(s);
		s=s+"george";
		System.out.println(s);
		String b;
		b="traing";
		//concate είναι η πρόσθεση στα αλφαριθμητικά. 
		s=s+b;
		System.out.println(s);	
	}
}
