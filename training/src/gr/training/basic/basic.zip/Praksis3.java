package gr.training.basic;
//Περισσοτερες πραξεις με int
public class Praksis3 {
	public static void main(String[] args) {
		//Οριζει μεταβλητή και ταυτόχρονα της θέτεις τιμή 
		int i = 0 ; 
		System.out.println(i);
		i=i+1;
		System.out.println(i);
		
		i=1+2+3+4+5;
		System.out.println(i);
		//αυτό σημαίνει ότι αυξάνω την τιμή του ακαιραίου κατά 1;
		i++;
		System.out.println(i);
		i=0;
		System.out.println(i);
		//Αυτό σημαινεί ότι τυ ππροσθέτω 2
		i+=2;
		System.out.println(i);
		i=10/2;
		System.out.println(i);
		i=2*5;
		System.out.println(i);
		i=12%3;
		System.out.println(i);
		//Χρήση παρενθέσων 
		i=(10+2)/6;
		System.out.println(i);
		//η διαίρεση προηγείται της πρόσθεσης
		i=10+6/6;
		System.out.println(i);
		
		i=11/3;
		System.out.println(i);
	}
}
