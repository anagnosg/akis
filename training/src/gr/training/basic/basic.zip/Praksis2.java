package gr.training.basic;

public class Praksis2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Ορισμός
		
		//Ανάθεση τιμής 0
		
		
		//αναθεση τιμή σε boolen τύπο  με την αντίθετη τιμή.
		//το ! είνια ο τελεστής not
		//τελεστές λέγοντοαι σύμβολα πράξεων 
		// to + σημαίνει πρόσθεση , πχ to 2+3 συμαίνει πρόσθεσε το 2 με το 3
		//το - σημαίνει αφαίρεση
		//το * σημαίνει πολλαπλασιασμός 
		// το / shmainei diairesh 
		// to % shmainei ypoloipo
		//to !shmainei not
		// oi telestes exoun diafotetiko nohma analoga me ton typo ths metablhths
		//π.χ 2+3 σημαινει πρόσθεσε το 2 με το 3 επόμενως 5
		// το "akis" + "george " shmainei ένωσε το κείμενο akis me to george 
		//to not !  ;exei nohma stis boolean metablhtes !"akis" den exeis nohma alla to !true 8a kanei false
		//θέσε στην μεταβλητή τύπου boolean με όνομα b το not b 
		boolean  b;
		b=false;
		System.out.println(b);
		b=!b;
		//ΕΚτύπωση
		System.out.println(b);
		
	}
}
