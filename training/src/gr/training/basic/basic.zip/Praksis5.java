package gr.training.basic;

public class Praksis5 {
	public static void main(String[] args) {
		float f ;
		f=1.3f;
		System.out.println(f);
		f=f+2.3f;
		System.out.println(f);
		
	}
}
