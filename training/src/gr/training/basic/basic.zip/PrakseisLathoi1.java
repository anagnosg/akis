package gr.training.basic;

public class PrakseisLathoi1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0 ; 
		i = 0/0;
		
	}

}
